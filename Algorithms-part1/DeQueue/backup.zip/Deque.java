import java.util.Iterator;
import java.util.NoSuchElementException;

public class Deque < Item> implements Iterable<Item>{
    private int head, tail, size, capacity;
    private Item[] items;
    public Deque(){
        head = 0;
        tail = 0;
        size = 0;
        capacity = 1;
        items = (Item[]) new Object[capacity];
    }

    public boolean isEmpty(){
        if (this.size == 0){
            return true;
        }
        return false;
    }

    public int size(){
        return this.size;
    }

    private void checkAdd(Item item){
        if (item == null){
            throw new NullPointerException();
        }
    }

    private void checkRemove(){
        if (this.size == 0){
            throw new NoSuchElementException();
        }

    }

    private boolean emptyAdd(Item item) {
        if (this.size == 0){
            this.head = 0;
            this.tail = 0;
            this.items[0] = item;
            return true;
        }
        return false;
    }

    public void addFirst(Item item){
        checkAdd(item);
        if (!emptyAdd(item)){
            if (head > 0){
                head -= 1;
                items[head] = item;
            }
            else{
                for (int i = tail; i>= head; i--){
                    items[i+1] = items[i];
                }
                this.tail += 1;
                items[head] = item;
            }
        }
        size += 1;
        resize();
    }

    public void addLast(Item item){
        checkAdd(item);
        if (!emptyAdd(item)){
            if (tail  <  capacity -1){
                this.tail += 1;
                items[tail] = item;
            }
            else{
                for (int i = head; i <=  tail; i++){
                    items[i-1] = items[i];
                }
                items[tail] = item;
            }
        }
        size += 1;
        resize();
    }

    public Item removeFirst(){
        checkRemove();
        Item a;
        if (head == tail){
            System.out.println("cap is "+capacity+"size is "+size+"head "+head+ "tail "+tail);
            a = items[head];
            head = 0;
            tail = 0;
        }
        else {
            a = items[head];
            head += 1;
        }
        size -= 1;
        resize();
        return a;
    }

    public Item removeLast(){
        checkRemove();
        Item a;
        if (head == tail){
            a = items[head];
            head = 0;
            tail = 0;
        }
        else {
            a = items[tail];
            tail -= 1;
        }
        size -= 1;
        resize();
        return a;
    }

    public Iterator < Item> iterator(){
        Iterator < Item> it = new Iterator<Item>(){
            private int index=head;

            public boolean hasNext(){
                return index>= head && index <=tail;
            }

            public Item next(){
                if (!this.hasNext()){
                    throw new NoSuchElementException();
                }
                return items[index++];
            }

            public void remove(){
                throw new UnsupportedOperationException();
            }
        };

        return it;
    }

    private void resize(){
        if (this.size ==0 || this.capacity == 0){
            return;
        }
        if (this.size == this.capacity){
            // while insertion if queue is full
            this.capacity = 2 * this.capacity;
            Item[] temp = (Item[]) new Object[this.capacity];
            for (int i = 0; i  <  this.size; i++){
                temp[i] = this.items[i];
            }
            this.items = temp;
        }else if(this.size  <= this.capacity/4){
            // while removal if memory is free
            this.capacity = this.capacity/4;
            Item[] temp = (Item[]) new Object[this.capacity];
            //System.out.println("cap is "+capacity+"size is "+size+"head "+head+ "tail "+tail);
            for (int i = head,j=0; i  <= tail; i++,j++){
                temp[j] = this.items[i];
            }
            this.items = temp;
        }
    }

    private void disp(){
        System.out.println("print "+this.size);
        for (int i = 0; i < this.size;i++){
            System.out.println(this.items[i]);
        }
    }

    public static void main(String[] args){
        Deque<Integer> deque = new Deque<Integer>();
       deque.isEmpty();
         deque.isEmpty();
         deque.isEmpty();
         deque.addFirst(3);
         deque.addFirst(4);
         deque.removeFirst();
         deque.removeFirst();
        System.out.println(deque.removeLast());
    }

}
