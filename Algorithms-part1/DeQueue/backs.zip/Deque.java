import java.util.Iterator;
import java.util.NoSuchElementException;

public class Deque<Item> implements Iterable<Item>{
    private int head, tail, size, capacity;
    private Item[] items;
    public Deque(){
        head = 0;
        tail = 0;
        size = 0;
        capacity = 1;
        items = (Item[]) new Object[capacity];
    }

    public boolean isEmpty(){
        if (this.size == 0){
            return true;
        }
        return false;
    }

    public int size(){
        return this.size;
    }

    private void checkAdd(Item item){
        if (item == null){
            throw new NullPointerException();
        }
    }

    private void checkRemove(){
        if (this.size == 0){
            throw new NoSuchElementException();
        }

    }

    public void addFirst(Item item){
        checkAdd(item);
        int head = this.head;
        int tail;
        this.size += 1;
        if (this.size == 1){
            this.items[0] = item;
        }else{
            if (head > 0){
                this.items[head-1] = item;
                this.head -= 1;
            }else {
                this.tail += 1;
                tail = this.tail;
                head = this.head;
                for(int i=tail-1; i >= head; i--){
                    // moving to one position right
                    this.items[i+1] = this.items[i];
                }
                this.items[head] = item;
            }
        }
        resize();
    }

    public void addLast(Item item){
        checkAdd(item);
        int head, tail;
        this.size += 1;
        if (this.size == 1){
            this.items[0] = item;
        }else{
            if (this.tail < this.capacity - 1){
                this.tail += 1;
                this.items[this.tail] = item;
            }else{
                this.head -= 1;
                head = this.head;
                tail = this.tail;
                for(int i=head; i <= tail; i++){
                    // moving to one position left;
                    this.items[i] = this.items[i+1];
                }
                this.items[tail] = item;
            }
        }
        resize();
    }

    public Item removeFirst(){
        checkRemove();
        Item a;
        this.size -= 1;
        if (this.size == 0){
            a = this.items[this.head];
            this.head = 0;
            this.tail = 0;
            return a;
        }
        a = this.items[this.head];
        this.head += 1;
        resize();
        return a;
    }

    public Item removeLast(){
        checkRemove();
        Item a;
        this.size -= 1;
        if (this.size == 0){
            a = this.items[this.head];
            this.head = 0;
            this.tail = 0;
            return a;
        }
        a = this.items[tail];
        this.tail -= 1;
        resize();
        return a;
    }

    public Iterator<Item> iterator(){
        Iterator<Item> it = new Iterator<Item>(){
            private int index=head;

            public boolean hasNext(){
                return index>=head && index<=tail;
            }

            public Item next(){
                if (!this.hasNext()){
                    throw new NoSuchElementException();
                }
                return items[index++];
            }

            public void remove(){
                throw new UnsupportedOperationException();
            }
        };

        return it;
    }

    private void resize(){
        if (this.size == this.capacity){
            // while insertion if queue is full
            this.capacity = 2 * this.capacity;
            Item[] temp = (Item[]) new Object[this.capacity];
            for(int i = 0; i < this.size; i++){
                temp[i] = this.items[i];
            }
            this.items = temp;
        }else if(this.size <= this.capacity/4){
            // while removal if memory is free
            //System.out.println(this.size+ " " +this.capacity);
            this.capacity = this.capacity/4;
            //System.out.println(this.head+ " " +this.tail);
            Item[] temp = (Item[]) new Object[this.capacity];
            for(int i = head,j=0; i <= tail; i++,j++){
                temp[j] = this.items[i];
            }
            this.items = temp;
        }
    }

    private void disp(){
        System.out.println("print");
        for(int i=this.head; i<=this.tail;i++){
            System.out.println(this.items[i]);
        }
    }

    public static void main(String[] args){
        Deque<Integer> deque = new Deque<Integer>();
         deque.addFirst(0);
         deque.addFirst(1);
         deque.isEmpty();
         deque.removeFirst();
    }

}
